package com.example.tp4;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class ContactsActivity extends AppCompatActivity {
    TextView tvNewContact;
    ListView listViewContacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);

        tvNewContact = findViewById(R.id.tvNewContact);
        listViewContacts = findViewById(R.id.listViewContacts);

        String nom = getIntent().getStringExtra("nom");
        String prenom = getIntent().getStringExtra("prenom");
        String telephone = getIntent().getStringExtra("telephone");

        tvNewContact.setText("Nouveau contact : " + nom + " " + prenom + " - " + telephone);

        ArrayList<String> contacts = new ArrayList<>();
        contacts.add(nom + " " + prenom + " - " + telephone);
        contacts.add("Alice Dupont - 123456789");
        contacts.add("Bob Martin - 987654321");
        contacts.add("Charlie Leblanc - 555666777");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, contacts);
        listViewContacts.setAdapter(adapter);
    }
}
