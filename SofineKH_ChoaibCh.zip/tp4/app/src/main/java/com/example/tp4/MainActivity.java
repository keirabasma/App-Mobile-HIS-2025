package com.example.tp4;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText etNom, etPrenom, etTelephone;
    Button btnSoumettre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNom = findViewById(R.id.etNom);
        etPrenom = findViewById(R.id.etPrenom);
        etTelephone = findViewById(R.id.etTelephone);
        btnSoumettre = findViewById(R.id.btnSoumettre);

        btnSoumettre.setOnClickListener(v -> {
            String nom = etNom.getText().toString();
            String prenom = etPrenom.getText().toString();
            String telephone = etTelephone.getText().toString();

            Intent intent = new Intent(MainActivity.this, ContactsActivity.class);
            intent.putExtra("nom", nom);
            intent.putExtra("prenom", prenom);
            intent.putExtra("telephone", telephone);
            startActivity(intent);
        });
    }
}
