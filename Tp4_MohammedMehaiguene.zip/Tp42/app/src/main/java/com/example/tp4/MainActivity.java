package com.example.tp4;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected <Intent, Textview> void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        Button submit = findViewById(R.id.button);
        TextView lv = findViewById(R.id.editTextText3);
        TextView cv = findViewById(R.id.editTextText2);
        TextView tv = findViewById(R.id.editTextText);
        submit.setOnClickListener(V->{Intent intnt = new Intent(this,Aff_contacte.class);

            intnt.putExtra("Nom",tv );
            intnt.putExtra("Numero",lv );
            intnt.putExtra("Prenom",cv );
            StartActivity(intnt);
            contactsList.add(tv + " ------" + lv + " ------ " + cv);
            Intent intent = new Intent(MainActivity.this, ListContactActivity.class);
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;



        });
    }
}